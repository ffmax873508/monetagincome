# Monetag Income

GitHub Pages-ready static website using Monetag Zone `10524680`.

## Deploy
1. Upload `index.html` to a GitHub repository.
2. Go to **Settings → Pages**.
3. Select the `main` branch and `/ (root)`.
4. Save and open the generated GitHub Pages URL.

The Monetag SDK is loaded from the integration code supplied for Zone `10524680`.
